===========
PyPSbuilder
===========

.. image:: https://readthedocs.org/projects/pypsbuilder/badge/?version=latest
        :target: http://pypsbuilder.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

Simplistic THERMOCALC front-end for constructing PT pseudosections


* Free software: GPLv3 license
* Documentation: http://pypsbuilder.readthedocs.io/en/latest/

