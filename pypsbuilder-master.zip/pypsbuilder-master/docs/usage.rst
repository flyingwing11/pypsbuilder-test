========
Usage
========

To use pypsbuilder, execute provided psbuilder script::

    $ psbuilder

