pyuic5 psbuilder.ui > ../ui_psbuilder.py
pyuic5 adduni.ui > ../ui_adduni.py
pyuic5 addinv.ui > ../ui_addinv.py
pyuic5 uniguess.ui > ../ui_uniguess.py

