#!/usr/bin/env python

import sys
from pypsbuilder import psbuilder


def main():
    sys.exit(psbuilder.main())


if __name__ == '__main__':
    main()
